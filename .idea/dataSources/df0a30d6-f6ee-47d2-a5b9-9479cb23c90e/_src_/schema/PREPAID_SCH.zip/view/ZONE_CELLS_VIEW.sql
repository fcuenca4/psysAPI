CREATE VIEW ZONE_CELLS_VIEW AS Select zc_Id
,Cell_Id
,Cell_Name
,Cell_CGI
,Cell_Latitude
,Cell_Longitude
,Cell_Radius
,Zone_id
,Zone_Name
,Zone_Description
From Zone_Cells
, Cells
, Zones
Where zc_Cell_Id = Cell_Id
And zc_Zone_id = Zone_id
/
