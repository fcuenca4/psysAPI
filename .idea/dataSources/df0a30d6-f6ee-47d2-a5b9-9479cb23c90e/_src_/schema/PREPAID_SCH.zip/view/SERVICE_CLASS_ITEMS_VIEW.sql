CREATE VIEW SERVICE_CLASS_ITEMS_VIEW AS Select SCI_ID
, SClass_ID
, SClass_Name
, SClass_Description
, SItem_ID
, SItem_Name
, SItem_Description
From Service_Class_Items
, Service_class
, Service_Items
Where SCI_SClass_ID = SClass_ID
And SCI_SItem_ID = SItem_ID
/
